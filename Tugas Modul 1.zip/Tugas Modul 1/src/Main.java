import java.util.Objects;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        // Membuat objek Scanner untuk input dari pengguna
        Scanner scanner = new Scanner(System.in);
        System.out.println("Selamat datang!");

        // Memulai loop untuk menu program
        while (true) {
            // Menampilkan menu
            System.out.println("\nSilakan pilih menu:");
            System.out.println("1. Login Mahasiswa");
            System.out.println("2. Login Admin");
            System.out.println("3. Keluar");
            System.out.print("Pilihan Anda: ");
            // Membaca pilihan menu dari pengguna
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            // Memproses pilihan menu
            switch (choice) {
                case 1:
                    loginMahasiswa(scanner); // Memanggil fungsi login mahasiswa
                    break;
                case 2:
                    loginAdmin(scanner); // Memanggil fungsi login admin
                    break;
                case 3:
                    System.out.println("Terima kasih!"); // Menampilkan pesan dan keluar dari program
                    System.exit(0);
                default:
                    System.out.println("\nPilihan tidak valid. Silakan coba lagi."); // Menampilkan pesan jika pilihan tidak valid
            }
        }
    }

    // Fungsi untuk login sebagai mahasiswa
    private static void loginMahasiswa(Scanner scanner) {
        System.out.print("\nMasukkan NIM Anda: "); // Meminta input NIM dari pengguna
        String nim = scanner.nextLine();

        // Memeriksa apakah NIM terdaftar
        if (nim.length() == 15) {
            System.out.println("\nLogin berhasil sebagai mahasiswa dengan NIM: " + nim); // Menampilkan pesan login berhasil
        } else {
            System.out.println("\nMaaf, NIM tidak terdaftar."); // Menampilkan pesan login gagal jika NIM tidak terdaftar
        }
    }

    // Fungsi untuk login sebagai admin
    private static void loginAdmin(Scanner scanner) {
        System.out.print("\nMasukkan username: "); // Meminta input username dari pengguna
        String username = scanner.nextLine();
        if (Objects.equals(username, "admin")) {
            System.out.print("Masukkan password: "); // Meminta input password dari pengguna
            String password = scanner.nextLine();
            if (Objects.equals(password, "admin")) {
                System.out.println("\nSuccesful login as admin");
            } else {
                System.out.println("\nCok lebokno password sing bener");
            }
        } else {
            System.out.println("\nUsernamemu gak kedaftar jancok");
        }


        // Memeriksa keautentikan admin
    }


}